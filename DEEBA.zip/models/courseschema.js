const mongoose = require('mongoose')


var CourseSchema= new mongoose.Schema({
name:{
    type: String
},
price:{
    type: Number
}


})

var Course = mongoose.model('Course', CourseSchema)
module.exports= Course;