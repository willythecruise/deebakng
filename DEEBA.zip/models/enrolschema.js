const mongoose= require('mongoose')


var EnrolSchema= new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  
  },
  course:{
    type: String,
  },
createdAt: {
    type: Date,
    default: Date.now
  
  },

  reference:{
    type:String,
    required:true
  },
  amount:{
    type: String
  },
  status:{
    type: Boolean,
    default: false
  }

})


const Enrol=  mongoose.model('Enrol', EnrolSchema);
module.exports= Enrol;